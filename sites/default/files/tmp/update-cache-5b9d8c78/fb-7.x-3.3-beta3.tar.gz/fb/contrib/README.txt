modules/fb/contrib/README.txt

(Read modules/fb/README.txt for important information.)

In this directory you'll find modules that are either:

* experimental
* under development
* useful only with certain third-party modules

These are not part of the "officially supported" Drupal for Facebook.
If problems arise, we'll help if we can.  But hopefully you can
provide your own patches to the issue queue:
http://drupal.org/project/issues/fb

Do you feel one of these modules should be "promoted" to the
modules/fb/ directory?  Do you have a module you'd like to contribute
to this directory?  Please let us know by submitting an issue:
http://drupal.org/project/issues/fb
